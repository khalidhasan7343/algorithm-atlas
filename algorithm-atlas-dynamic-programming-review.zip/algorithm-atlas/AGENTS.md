# Algorithm Atlas working instructions

## Read before changing the project

Read `README.md`, `CONTRIBUTING.md`, `docs/progress.md`, and the relevant records in `catalog.yaml`. The project owner and maintainer is **MD.Khalid Hasan**; preserve the attribution and MIT licensing. The target repository is `https://github.com/khalidhasan7343/algorithm-atlas`.

## Mandatory phase checkpoint

The owner explicitly approved Phase 4 — Divide & Conquer on 2026-10-22 (Asia/Dhaka) and authorized **Phase 5 — Dynamic Programming: the eleven listed canonical topics only**. Preserve all earlier work. A12 retains 13 memberships: the eleven DP-owned topics in this phase plus Bellman-Ford and Floyd-Warshall, which remain planned shared graph topics outside scope.

Follow the four sequential validated [batches](docs/dynamic-programming-checkpoints.md); continue automatically between internal batches. Each new lesson requires the exact 25 sections, recurrence, correctness, numeric/resource contracts, Python/C++17/C++20 tests, and independent expected values. Record actual results, regenerate catalog documentation, and prepare DYNAMIC-PROGRAMMING-REVIEW-REPORT.md plus the full review ZIP and SHA-256. Then STOP for explicit owner review. Do not mark Phase 5 human-approved, begin another category, commit, push, or publish. Every subsequent authorized scope also ends at an explicit owner review checkpoint. Never set Git identity from the public contact email.

## Work and validation

- Keep all original syllabus items in the catalog, reuse canonical topics, and document meaningful variants.
- Planning READMEs are scope records, not completed algorithm lessons. Implemented lessons require the 25 sections in `docs/development.md`, Python/C++ code, examples, and meaningful tests.
- Use actual evidence for status changes. Keep the Dynamic Policy Optimization topic blocked until its intended reference is clarified; see `docs/terminology-decisions.md`.
- Regenerate index/progress documentation after catalog changes with `python scripts/generate_catalog_docs.py`. Preserve hand-written lessons.
- Run `python scripts/validate_catalog.py`, `python scripts/generate_catalog_docs.py --check`, and `python -m pytest --require-cpp` after relevant changes. Report failures, skips, and missing tools precisely.
- Keep secrets, virtual environments, generated binaries, model weights, and large datasets out of version control.

Use the local `.venv` when available. A configured workflow is not evidence that hosted GitHub Actions has run.
