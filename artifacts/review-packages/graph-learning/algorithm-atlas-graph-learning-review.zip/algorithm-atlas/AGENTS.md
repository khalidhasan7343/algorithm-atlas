# Algorithm Atlas working instructions

## Read before changing the project

Read `README.md`, `CONTRIBUTING.md`, `docs/progress.md`, and the relevant records in `catalog.yaml`. The project owner and maintainer is **MD.Khalid Hasan**; preserve the attribution and MIT licensing. The target repository is `https://github.com/khalidhasan7343/algorithm-atlas`.

## Mandatory phase checkpoint

The owner **MD.Khalid Hasan** explicitly approved the verified Phase20 B8
handoff on **2026-10-31 Asia/Dhaka** and authorized **Phase21 — B9 Graph-Based
Learning only**. Complete its three existing canonicals in three batches:
PageRank,Node2Vec,Graph Convolutional Networks. See the
[scope](docs/graph-learning-scope.md) and
[checkpoints](docs/graph-learning-checkpoints.md). Preserve B1–B8/DSA
implementations,tests,lessons and historical artifacts,including B7 GNN and the
shared vanilla AE/CNN canonicals. Inventory stays35 categories/256 memberships/
235 canonicals. B8 remains9 completed+1 intentionally blocked DPO; its separate
Outcome3 decision is owner-approved: remain blocked. Never rename,substitute or
mark DPO complete.

B9 requires from-scratch Python/NumPy,independent stationary/walk/forward oracles,
finite-difference gradients,permutation equivariance and exact25-section lessons.
ML C++ is optional; DSA keeps Python/C++17/C++20. No heavyweight framework,
external dataset/weights or fabricated learning. Continue automatically through
passing internal batches. Deliver the tracked report and verified ZIP/checksum/
JSON,then STOP for owner review. **Phase21 owner approval pending.** No Phase22,
other category,commit,push,tag,release or publication. Never set Git identity
from public email.



## Work and validation

- Keep all original syllabus items in the catalog, reuse canonical topics, and document meaningful variants.
- Planning READMEs are scope records, not completed algorithm lessons. Implemented lessons require the 25 sections in `docs/development.md`, track-required code, examples, and meaningful tests; see `docs/ml-development.md`.
- Use actual evidence for status changes. Keep the Dynamic Policy Optimization topic blocked until its intended reference is clarified; see `docs/terminology-decisions.md`.
- Regenerate index/progress documentation after catalog changes with `python scripts/generate_catalog_docs.py`. Preserve hand-written lessons.
- Run `python scripts/validate_catalog.py`, `python scripts/generate_catalog_docs.py --check`, and `python -m pytest --require-cpp` after relevant changes. Report failures, skips, and missing tools precisely.
- Keep secrets, virtual environments, generated binaries, model weights, and large datasets out of version control.

Use the local `.venv` when available. A configured workflow is not evidence that hosted GitHub Actions has run.


## Review files and root organization

Future phase reports belong in `docs/reviews/<phase-name>/`; ZIPs, checksums and package JSON belong in `artifacts/review-packages/<phase-name>/`. Keep only essential project documentation, configuration and established source/infrastructure directories at the root. Update `development.completion_report`, live Markdown links, tracking checks and packaging paths whenever a report moves. Every completion report must exist, be nonempty, tracked and unignored.

The final review ZIP must contain the updated repository and required reports, excluding caches, virtual environments, secrets, binaries and unnecessary nested review archives/sidecars. Preserve genuine historical ZIPs and execution evidence; their internal snapshot paths/hashes remain historical. Do not force-add ignored artifacts. Existing phase-owner approval checkpoints remain mandatory; maintenance itself does not approve phases; the owner subsequently approved Phase 10 and authorized combined Phases 11 and 12 with separate owner checkpoints. Do not commit, push or publish without explicit owner authorization.
