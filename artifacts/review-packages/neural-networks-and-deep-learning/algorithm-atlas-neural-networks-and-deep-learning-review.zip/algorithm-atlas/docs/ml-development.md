# Machine Learning development standard

Maintainer: **MD.Khalid Hasan**. [MIT License](../LICENSE).
The owner explicitly approved the latest Phase18 Association Rule Learning
review/package on client session date2026-10-30 Asia/Dhaka and authorized
**Phase19 — B7 Neural Networks and Deep Learning only**. Complete its14 catalog
canonicals in the7 requested batches; see [scope](neural-networks-and-deep-learning-scope.md)
and [checkpoints](neural-networks-and-deep-learning-checkpoints.md). Preserve
the approved B5/B7 vanilla autoencoder byte-for-byte and one shared CNN canonical
for B7/C10. Protect prior B1–B6/DSA code/tests/lessons and historical review artifacts.
Inventory stays35 categories /256 memberships /235 canonicals.

B7 requires genuine NumPy forward/backprop/training, independent gradient/oracle/
numerical tests and exact25-section lessons. C++ is optional for all authorized ML;
DSA retains Python/C++ and actual C++17/C++20. AI remains under its existing policy.
No heavyweight neural framework, external dataset/weight download or fake C++.
Continue automatically through passing internal batches. Deliver the tracked report
and verified ZIP/checksum/JSON, then STOP for owner review. **New Phase19 owner
approval pending.** No Phase20/B8/other category, commit, push, tag, release or
publication. Never set Git identity from public email.




## Track and language policy

| Track | Required implementation/tests | C++ policy |
| --- | --- | --- |
| DSA | Python, C++, Python tests, C++ tests | Both C++17 and C++20 remain mandatory |
| Classical ML | Python, numerical tests, mathematical explanation, reproducible examples | Optional; source and executable C++ test must be provided together |
| B7 Neural Networks and Deep Learning | Python/NumPy, explicit gradients, numerical tests | Optional C++ |
| Future AI | Not authorized here | Retains previous structural rules |

[The central policy](../scripts/track_policy.py) identifies tracks from canonical
paths checked against their catalog owners. Phase19 extends the same Python-first NumPy policy to all B7 canonical paths; existing catalog ownership/path and DSA/AI checks remain mandatory.
The catalog schema and status vocabulary are unchanged. A Python-only ML record
leaves `cpp_status: planned`, explicitly meaning optional and not implemented;
this does not prevent Python-based completion. Optional C++ source/test files
must form a nonempty pair, have truthful statuses, use the shared compiler
fixtures, and execute under C++17/C++20 when supplied. Partial optional C++ is
invalid. All completed algorithms require Python source and Python tests.

`python -m pytest --require-cpp` still discovers all four roots and enforces
compiler availability for DSA tests. Python-only ML tests never request C++
fixtures. Neither DSA requirements nor its existing tests are removed.

## Runtime and reference dependencies

DSA-only setup remains `python -m pip install -r requirements-dev.txt` and
`python -m pytest tests dsa --require-cpp`. Install `requirements-ml.txt` for ML
runtime, or `requirements-ml-test.txt` for the full suite with reference tests.
NumPy supplies array/linear-algebra primitives. scikit-learn is a development
reference only; core solutions never import it. No deep-learning framework,
dataset download, pickle loader or model checkpoint is introduced.

Full local/CI setup:

```sh
python -m pip install -r requirements-ml-test.txt
python scripts/validate_catalog.py
python scripts/generate_catalog_docs.py --check
python -m pytest --require-cpp
python -m pytest machine-learning/supervised-learning/regression -q
```

Tests require their dependencies and fail clearly when absent. They do not
silently skip required numerical/reference verification. CI installs the ML
test requirements alongside unchanged DSA dependencies.

## Algorithms and numerical contracts

Every topic exposes its genuine mathematical logic. Reusing a canonical topic
(Polynomial Regression uses Linear Regression) is explicit; NumPy SVD/least
squares is a numerical primitive, not a hidden estimator. Define the exact loss
normalization, intercept treatment, regularization, optimization, stopping
conditions and failure behavior. Deterministic bounded solvers expose iteration
and convergence diagnostics. Exhausting a convergence-required solver raises an explicit convergence error.
Finite-budget embedding/neural experiments expose converged_, optimization_status_
and objective history without claiming convergence; see the B5 contracts.

Dense single-output float64 regression is the initial scope. Inputs have shape
`X=(n_samples,n_features)`, `y=(n_samples,)`; one-dimensional X or column-vector
y is rejected rather than guessed. Validate real numeric dtype, finite values,
resource/numeric limits and matching dimensions. Models copy training state and
do not mutate user arrays or global random state. Predict-before-fit is an error.
Document what a failed refit does to a prior fitted model. Fit preprocessing only
on training data; retain it for inference and keep held-out data separate.

Use stable least squares instead of normal-equation inversion, unpenalized
intercepts, explicit zero-column handling, checked nonfinite computations,
appropriate condition/rank diagnostics, and bounded matrix/feature expansion.
No solver can promise convergence on every ill-conditioned dataset. Hyperparameter
choices, scaling requirements and numerical tolerances must be stated.

## Documentation, tests and experiments

Keep the exact [25-section template](development.md#required-algorithm-readme-sections).
Use section 14, **C++ Implementation**, to state that C++ is optional and absent,
with no dummy files. Cover objectives, derivations, assumptions, training and
inference, shapes/state, hyperparameters, numerical stability, stopping criteria,
complexity, a worked numerical dry run, evaluation, limitations and references.

Tests include analytical solutions or independent optimization, smooth-gradient
finite differences (away from L1/epsilon kinks), KKT/duality checks where relevant,
known splits for trees, deterministic synthetic data, invalid shapes, constant and
singular features, held-out predictions, bounded non-convergence and failed-refit
state. scikit-learn comparisons align objective scaling and intercepts, compare
predictions/objectives when nonunique coefficients differ, and do not assume the
same optimizer or tie rules. Seeds, sample counts and tolerances are recorded.

Examples and modest benchmarks are local and reproducible. Report training and
test metrics separately; no uncontrolled performance-superiority claims or CI
wall-clock thresholds. Test results, audit results and owner approval are distinct.
Final review uses the existing report/package folders and stops for explicit owner
approval before any next ML category.

## Classification extension — Phase 14

The [classification contracts](classification-conventions.md) define strict label
families, binary versus multiclass APIs, class/probability ordering, numeric and
categorical domains, convergence/errors, metrics and held-out evaluation. They
extend this Python-first foundation without changing B1 or DSA implementations.

## Ensemble extension — Phase 15

The [B3 contracts](ensemble-methods-conventions.md) specify factory independence,
bootstrap and split RNGs, hard versus soft probability semantics, ordered prefix
boosting, target-statistic leakage avoidance and out-of-fold meta-training.
The exact variants and their deliberately bounded resource limits are part of the
lessons. XGBoost/CatBoost production-library parity is not claimed.

## Clustering extension — Phase 16

The [B4 contracts](clustering-conventions.md) define fit(X), label/metric semantics,
transductive versus meaningful new-row methods, bounded convergence and numerical
limits. Phase 16 [scope](clustering-scope.md) is now owner-approved; historical handoff evidence remains unchanged.
K-Means is reused canonically by GMM initialization and spectral partitioning.
Hierarchies/DBSCAN/HDBSCAN/spectral do not expose an invented centroid predictor.
Clustering metrics use explicit noise coverage and label-permutation agreement;
likelihood and held-out assignment are reported only where meaningful.

## Dimensionality reduction extension — Phase 17

See [B5 contracts](dimensionality-reduction-conventions.md) for decomposition, supervised projection, independence, graph/probability embedding and canonical NumPy reconstruction semantics. B4 historical handoff approval fields remain generation-time evidence; current Phase 16 approval is recorded in the catalog.

## Association Rule Learning extension — Phase18

[Transactions and exact thresholds](association-rule-learning-conventions.md) replace
numeric feature matrices for B6. Standard-library combinatorial core logic is
appropriate; NumPy is used only where useful in independent references. Frequent
itemsets and rule support/confidence/lift have distinct contracts. Each miner has
its own mechanism; shared rules do not add a catalog canonical. Earlier B5 contracts
and all language policies are preserved.
