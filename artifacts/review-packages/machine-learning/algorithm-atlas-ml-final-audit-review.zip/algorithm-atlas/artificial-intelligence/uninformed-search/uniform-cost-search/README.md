# Uniform Cost Search (UCS)

<!-- algorithm-atlas:planning-page -->

**Planned topic.** The full educational algorithm article, Python implementation, C++ implementation, executable examples, and algorithm tests have not been created.

## Purpose and planned scope

Explore state-space paths in order of accumulated nonnegative cost. State-space best-first formulation with goal termination and nonnegative action costs. Keep its search-state contract explicit and compare with graph shortest-path Dijkstra, whose graph interface is documented separately. Phase 0 planning record only; the full algorithm documentation, implementations, usage examples, and tests remain pending.

**Planned learning difficulty:** intermediate.

**Canonical location:** `artificial-intelligence/uninformed-search/uniform-cost-search`.

## Original syllabus memberships

- [C1. Uninformed Search](../README.md) — Uniform Cost Search (UCS).

## Current status

| Deliverable | Status |
| --- | --- |
| Full algorithm documentation | planned |
| Python implementation | planned |
| C++ implementation | planned |
| Algorithm tests | planned |

A planning README does not satisfy the completed documentation requirement. No implementation files or algorithm tests are currently available for this planned topic.

## Requirements before completion

In an approved implementation phase, define the input/output contract and prerequisites; write the full 25-part article with intuition, working process, pseudocode, dry run, bounded complexity analysis, applications, limitations, and verifiable references; add Python and C++ implementations with reproducible usage; and execute meaningful edge-case tests. Follow [the project contribution standards](../../../CONTRIBUTING.md) and update the catalog only when evidence supports each status.

## Related planned topics

- [Dijkstra's Algorithm](../../../dsa/graph-algorithms/dijkstra/README.md)
- [A* Search](../../../dsa/graph-algorithms/a-star-search/README.md)

## Review gate and attribution

Check the progress tracker for the current authorization. Do not begin this planned topic until it is included in the user’s approved scope.

Algorithm Atlas is maintained by [MD.Khalid Hasan](https://github.com/khalidhasan7343). Contribution and review rules are in [CONTRIBUTING.md](../../../CONTRIBUTING.md).

[Project home](../../../README.md) · [Complete index](../../../docs/algorithm-index.md) · [Progress](../../../docs/progress.md)
